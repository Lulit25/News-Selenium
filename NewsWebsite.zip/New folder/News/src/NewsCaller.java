public class NewsCaller {
}
