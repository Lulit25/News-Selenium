import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class News {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver","chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.navigate().to("http://time.com/");
        //driver.navigate().to("http://www.foxnews.com/science/2018/06/07/what-has-nasa-found-on-mars-get-set-for-major-announcement.html");
        WebElement title = driver.findElement(By.xpath("/html/body/div[5]/div/div[1]/div[1]"));
        WebElement body = driver.findElement(By.xpath("/html/body/div[5]/div/div[1]"));
        title.getText();
        System.out.println(title.getText());
        System.out.println(body.getText());

        WebDriver newsdriver = new ChromeDriver();
        //newsdriver.navigate().to("http://localhost/kiralanos/hompage.html");
        newsdriver.navigate().to("http://localhost:8000/index.html");
        newsdriver.findElement(By.id("newtitle")).sendKeys(title.getText());
        newsdriver.findElement(By.id("search-input")).sendKeys(body.getText());
        newsdriver.findElement(By.name("AddNews")).click();

        driver.navigate().to("http://www.cnn.com/");
        WebElement title2 = driver.findElement(By.xpath("//*[@id=\"homepage1-zone-1\"]/div[2]/div/div[1]/ul/li[1]/article/a/h2"));
        WebElement body2 = driver.findElement(By.xpath("//*[@id=\"homepage1-zone-1\"]/div[2]/div/div[1]/ul/li[1]/article/div/div[2]/h3/a/span[1]/strong"));
        System.out.println(title2.getText());
        System.out.println(body2.getText());
        // newsdriver.navigate().back();
        newsdriver.navigate().refresh();
        //body2.clear();
        newsdriver.findElement(By.id("newtitle")).sendKeys(title2.getText());
        newsdriver.findElement(By.id("search-input")).sendKeys(body2.getText());
        newsdriver.findElement(By.name("AddNews")).click();




//        driver.navigate().to("https://www.bbc.com/amharic");
//        WebElement title3 = driver.findElement(By.cssSelector(".buzzard-item > a:nth-child(1) > h3:nth-child(1) > span:nth-child(1)"));
//        System.out.println(title3.getText());
//        WebElement body3 = driver.findElement(By.cssSelector(".buzzard__body"));
//        System.out.println(body3.getText());
//        newsdriver.navigate().back();
//        newsdriver.navigate().refresh();
//        newsdriver.findElement(By.name("Title")).sendKeys(title3.getText());
//        newsdriver.findElement(By.name("content")).sendKeys(body3.getText());
//        newsdriver.findElement(By.name("submit")).click();




        //driver.findElement(By.xpath("//*[@id='block-gavias-kama-content']/div/div/div/div/div[1]/article/div/div[2]/h3/a")).getText();

        try {
            Thread.sleep(10000);
        }catch (Exception E){

        }
        driver.close();
        newsdriver.close();
    }
}
